from __future__ import annotations

import random
import math
import torch
from collections.abc import Sequence
from pathlib import Path

from isaaclab_compat import (
    BLUE_ARROW_X_MARKER_CFG,
    CUBOID_MARKER_CFG,
    GREEN_ARROW_X_MARKER_CFG,
    RED_ARROW_X_MARKER_CFG,
    BaseEnvWindow,
    DirectRLEnv,
    DirectRLEnvCfg,
    GroundPlaneCfg,
    InteractiveSceneCfg,
    RigidObject,
    RigidObjectCfg,
    SimulationCfg,
    VisualizationMarkers,
    configclass,
    math_utils,
    quat_apply,
    quat_conjugate,
    sim_utils,
    spawn_ground_plane,
)

##
# Hydrodynamic model
##
try:
    from .assets.easyuuv import EasyUUV_CFG
    from .rigid_body_hydrodynamics import HydrodynamicForceModels
    from .thruster_dynamics import get_thruster_com_and_orientations
except ImportError:
    from assets.easyuuv import EasyUUV_CFG
    from rigid_body_hydrodynamics import HydrodynamicForceModels
    from thruster_dynamics import get_thruster_com_and_orientations

from koopman.mpc import MPCBounds, MPCConfig, MPCWeights
from koopman.mpc_controller import KoopmanMPCController
from koopman.phase5_2_profiles import LEGACY_REWARD_PROFILE, PHASE5_2_REWARD_PROFILE
from koopman.phase5_2_reward import Phase52RewardConfig, compute_phase52_reward_components
from koopman.runtime import load_koopman_runtime

class EasyUUVEnvWindow(BaseEnvWindow):
    def __init__(self, env: EasyUUVEnv, window_name: str = "IsaacLab"):
        """Initialize the window.

        Args:
            env: The environment object.
            window_name: The name of the window. Defaults to "IsaacLab".
        """
        # initialize base window
        super().__init__(env, window_name)
        # add custom UI elements
        with self.ui_window_elements["main_vstack"]:
            with self.ui_window_elements["debug_frame"]:
                with self.ui_window_elements["debug_vstack"]:
                    # add command manager visualization
                    self._create_debug_vis_ui_element("targets", self.env)

@configclass
class EasyUUVEnvCfg(DirectRLEnvCfg):
    ui_window_class_type = EasyUUVEnvWindow

    sim: SimulationCfg = SimulationCfg(dt=1 / 120)

    # robot
    robot_cfg: RigidObjectCfg = EasyUUV_CFG.replace(prim_path="/World/envs/env_.*/Robot")

    # scene
    scene: InteractiveSceneCfg = InteractiveSceneCfg(num_envs=4, env_spacing=4.0, replicate_physics=True)
    debug_vis = True

    # env
    decimation = 2
    cap_episode_length = True
    episode_length_s = 3.0
    episode_length_before_reset = None
    action_space = 4
    observation_space = 9
    state_space = 0
    num_actions = 4 
    num_observations = 9 
    num_states = 0
    use_boundaries = True
    max_auv_x = 7
    max_auv_y = 7
    max_auv_z = 7
    starting_depth = 1.5 
    min_goal_steps = 100
    goal_completion_radius = 0.01
    goal_dims = 4
    eval_mode = False

    goal_spawn_radius = 2.0
    init_guidance_rate = 0.1
    init_vel_max = 1.0

    # rewards
    rew_scale_terminated = 0.0
    rew_scale_alive = 0.0
    rew_scale_completion = 1000

    rew_scale_pos = 0.15
    rew_scale_ang = 0.5
    rew_scale_vel = 0.0
    rew_scale_ang_vel = 0.0
    rew_scale_lin_vel = 0.0
    rew_scale_actions = 0.00
    reward_profile = LEGACY_REWARD_PROFILE
    phase5_2_pwm_soft_limit = 0.90
    phase5_2_latency_ref_ms = 20.0
    phase5_2_latency_clip = 3.0
    phase5_2_w_fallback = 0.30
    phase5_2_w_pwm_sat = 0.20
    phase5_2_w_latency = 0.05
    phase5_2_w_action = 0.01
    phase5_2_w_delta_action = 0.02

    # dynamics
    com_to_cob_offset = [0.0, 0.0, 0.01] # in meters, add this (xyz) to COM to get COB location
    water_rho = 997.0 # kg/m^3
    water_beta = 0.001306 # Pa s, dynamic viscosity of water @ 50 deg F
    rotor_constant = 0.1 / 100.0 # rotor constant used in Gazebo, note /10 because 0.04 is "10x bigger than it should be"
    dyn_time_constant = 0.05 # time constant for linear dynamics for each rotor 
    volume = 0.0187613 
    mass = 1.88e+01 # kg
    PID_init_args = torch.tensor([[1.00, 0.13, 0.00], # x-axis rotation, Roll
                     [1.00, 0.13, 0.00], # y-axis rotation, Pitch
                     [1.67, 0.22, 0.00], # z-axis rotation, Yaw
                     [0.27, 0.12, 0.00]], device='cuda:0') # depth
    
    controller_mode = 'legacy'
    control_method = 'Ssurface' # Ssurface & PID
    s_ratio = 4 # (Ssurface coeff / PID coeff)
    self_adapt = True # dummy if control_method == 'PID'
    koopman_manifest_path = ''
    mpc_horizon = 5
    mpc_timeout_ms = 12.0
    mpc_delta_pwm_limit = 0.35
    mpc_depth_weight = 1.0
    mpc_attitude_weight = 1.0
    mpc_control_weight = 0.01
    mpc_smoothness_weight = 0.05

     # domain randomization
    # todo: isaaclabs has a built-in method somehow
    class domain_randomization:
        use_custom_randomization = False
        com_to_cob_offset_radius = 0.075
        volume_range = [0.0187613 - 0.003, 0.0187613 + 0.003]
        mass_range = [1.88e+01,1.88e+01] # uniform [lowerbound, upperbound]


class EasyUUVEnv(DirectRLEnv):
    cfg: EasyUUVEnvCfg

    def __init__(self, cfg: EasyUUVEnvCfg, render_mode: str | None = None, **kwargs):
        super().__init__(cfg, render_mode, **kwargs)

        # Debug mode?
        self._debug = False

        # Initialize buffers
        self._actions = torch.zeros(self.num_envs, self.cfg.num_actions, device=self.device)
        self._thrust = torch.zeros(self.num_envs, 1, 3, device=self.device)
        self._moment = torch.zeros(self.num_envs, 1, 3, device=self.device)
        self._goal = torch.zeros(self.num_envs, self.cfg.goal_dims, device=self.device)
        self._default_root_state = torch.zeros(self.num_envs, 13, device=self.device)
        self._completion_buffer = torch.zeros(self.num_envs, device=self.device)
        self._completed_envs = torch.zeros(self.num_envs, device=self.device, dtype=torch.bool)
        self._default_env_origins = torch.zeros(self.num_envs, 3, device=self.device)
        self._goal_pos_w = self._default_env_origins # just for visualizations at the moment
        self._step_count = 0
        self._last_pwm_8d = torch.zeros(self.num_envs, 8, device=self.device)
        self._last_action_delta_4d = torch.zeros(self.num_envs, self.cfg.num_actions, device=self.device)
        self._last_koopman_mpc_diagnostics = [{} for _ in range(self.num_envs)]
        self._last_phase5_2_reward_components = {}
        
        # Get thruster configurations
        self.thruster_com_offsets, self.thruster_quats = get_thruster_com_and_orientations(self.device)
        self.thruster_com_offsets = self.thruster_com_offsets.unsqueeze(0).repeat(self.num_envs, 1, 1).to(self.device)
        self.thruster_quats = self.thruster_quats.repeat(self.num_envs, 1).to(self.device)

        self.PID_args = torch.zeros(self.num_envs, self.cfg.num_actions, 3, device=self.device)
        self.old_actions = torch.zeros(self.num_envs, self.cfg.num_actions, device=self.device)
        self.actions_i = torch.zeros(self.num_envs, self.cfg.num_actions, device=self.device)
        self.action_lim = torch.tensor([0.3, 0.3, 0.3, 0.3]).reshape(1, 4).to(self.device)

        self.log_MSE = torch.zeros(self.num_envs, dtype=torch.float, device=self.device)

        torch.manual_seed(0)

        if self.cfg.eval_mode:
            print("Setting manual seed")
            torch.manual_seed(0)

        # Debug visualization
        self.set_debug_vis(self.cfg.debug_vis)

        if self._debug: print("mass: ", list(self._robot.root_physx_view._masses))

        # Get specific information about the AUV
        self._gravity_magnitude = torch.tensor(self.sim.cfg.gravity, device=self.device).norm()

        # todo: get inertias from the model or physx view
        self.inertia_tensors = torch.zeros((self.num_envs, 3), device=self.device, dtype=torch.float, requires_grad=False)

        # estimated inertial values from a solid rect. prism model (with estimated side lengths of 0.7m, 0.4m, and 0.2m):
        # fake inertial values for warpauv, based on I_ii = (1/12) * mass * (len_j**2 + len_k**2)
        self.inertia_tensors[:, 0] = 0.37
        self.inertia_tensors[:, 1] = 0.97
        self.inertia_tensors[:, 2] = 1.19

        if self.cfg.mass:
            self.masses = torch.full((self.num_envs, 1), self.cfg.mass, device=self.device)
        else:
            self.masses = self._robot.root_physx_view._masses

        # todo: cleaner way to handle this
        if type(self.cfg.com_to_cob_offset) != torch.Tensor:
            self.com_to_cob_offsets = torch.tensor(self.cfg.com_to_cob_offset).repeat(self.num_envs, 1).to(self.device)
        else:
            self.com_to_cob_offsets = self.cfg.com_to_cob_offset.copy()

        if type(self.cfg.volume) != torch.Tensor:
            self.volumes = torch.full((self.num_envs, 1), self.cfg.volume, device=self.device)
        else:
            self.volumes = self.cfg.volume.copy()

        # PID
        self.PID_args = torch.tensor(self.cfg.PID_init_args).reshape(1, 4, 3).repeat(self.num_envs, 1, 1).to(self.device)

        self.inertia_tensors_mean = self.inertia_tensors.mean(dim=1, keepdim=True) 

        self._koopman_mpc_controller = None
        if self.cfg.controller_mode == 'koopman_mpc':
            self._init_koopman_mpc_controller()

        # Initialize dynamics calculators
        self._init_thruster_dynamics()
        
        # Set initial goals
        self._reset_idx(self._robot._ALL_INDICES)

    def _init_koopman_mpc_controller(self):
        if not self.cfg.koopman_manifest_path:
            raise ValueError("koopman_manifest_path is required when controller_mode == 'koopman_mpc'")
        runtime = load_koopman_runtime(self.cfg.koopman_manifest_path, project_root=Path(__file__).resolve().parent)
        config = MPCConfig(
            horizon=int(self.cfg.mpc_horizon),
            timeout_ms=float(self.cfg.mpc_timeout_ms),
            bounds=MPCBounds(delta_pwm_limit=float(self.cfg.mpc_delta_pwm_limit)),
            weights=MPCWeights(
                depth=float(self.cfg.mpc_depth_weight),
                attitude=float(self.cfg.mpc_attitude_weight),
                control=float(self.cfg.mpc_control_weight),
                smoothness=float(self.cfg.mpc_smoothness_weight),
            ),
        )
        self._koopman_mpc_controller = KoopmanMPCController(runtime, config)

    def _koopman_state_reference(self) -> tuple[torch.Tensor, torch.Tensor]:
        state = torch.cat(
            [
                self._robot.data.root_pos_w[:, 2].unsqueeze(1),
                self._robot.data.root_quat_w,
                self._robot.data.root_lin_vel_b,
                self._robot.data.root_ang_vel_b,
            ],
            dim=1,
        )
        reference = getattr(self, "_koopman_reference_5d", None)
        if reference is None:
            depth_reference = torch.zeros((self.num_envs, 1), device=self.device)
            reference = torch.cat([depth_reference, self._goal], dim=1)
        return state, reference.to(self.device)

    def _init_thruster_dynamics(self):
        if type(self.cfg.com_to_cob_offset) != torch.Tensor:
          self.cfg.com_to_cob_offset = torch.tensor(self.cfg.com_to_cob_offset, device=self.device, dtype=torch.float32, requires_grad=False).reshape(1,3).repeat(self.num_envs, 1)

        # get force calculation functions and rotor dynamics models
        self.force_calculation_functions = HydrodynamicForceModels(self.num_envs, self.device, False)

    def _setup_scene(self):
        self.cfg.robot_cfg.init_state = RigidObjectCfg.InitialStateCfg(pos=(0.0, 0.0, self.cfg.starting_depth))
        self._robot = RigidObject(self.cfg.robot_cfg)

        spawn_ground_plane(prim_path="/World/ground", cfg=GroundPlaneCfg())

        self.scene.clone_environments(copy_from_source=False)
        self.scene.filter_collisions(global_prim_paths=[])

        self.scene.articulations["robot"] = self._robot

        light_cfg = sim_utils.DomeLightCfg(intensity=2000.0, color=(0.75, 0.75, 0.75))

        light_cfg.func("/World/Light", light_cfg)

    def _pre_physics_step(self, actions: torch.Tensor) -> None:
        if self._debug: print("original actions vec: ", actions)
        if self._debug: print("concatenated actions shape: ", self._actions)

        self._actions[:] = actions
        self._actions[:] = torch.clip(self._actions, -1, 1).to(self.device)

    def _apply_action(self) -> None:
        self._thrust[:,0,:], self._moment[:,0,:] = self._compute_dynamics(self._actions)
        self._robot.set_external_force_and_torque(self._thrust, self._moment)

    def _get_observations(self) -> dict:
        offset_from_origin_b = quat_apply(quat_conjugate(self._robot.data.root_quat_w), self._default_env_origins - self._robot.data.root_pos_w)
        obs = torch.cat(
            [
                self._goal, # 4
                self._robot.data.root_pos_w[:,2].unsqueeze(1), # 1
                self._robot.data.root_quat_w,# 4
            ],
            dim=-1
        )
        observations = {"policy": obs}
        return observations

    def _phase5_2_solver_health_tensors(self) -> tuple[torch.Tensor, torch.Tensor]:
        fallback_used = torch.zeros(self.num_envs, dtype=torch.float32, device=self.device)
        latency_ms = torch.zeros(self.num_envs, dtype=torch.float32, device=self.device)
        for env_index, diagnostics in enumerate(self._last_koopman_mpc_diagnostics):
            if not isinstance(diagnostics, dict):
                continue
            fallback_used[env_index] = 1.0 if diagnostics.get("fallback_used", False) else 0.0
            latency_ms[env_index] = float(diagnostics.get("latency_ms", 0.0) or 0.0)
        return fallback_used, latency_ms

    def _record_phase5_2_reward_components(self, components: dict[str, torch.Tensor]) -> None:
        self._last_phase5_2_reward_components = {
            field_name: values.detach().cpu().reshape(-1).tolist()
            for field_name, values in components.items()
        }

    def _get_rewards(self) -> torch.Tensor:
        offsets_from_origin = quat_apply(quat_conjugate(self._robot.data.root_quat_w), self._default_env_origins - self._robot.data.root_pos_w)

        legacy_reward = _compute_rewards(
            self.cfg.rew_scale_pos,
            self.cfg.rew_scale_ang,
            self.cfg.rew_scale_lin_vel,
            self.cfg.rew_scale_ang_vel,
            self.cfg.rew_scale_actions,
            self._robot.data.root_lin_vel_b,
            self._robot.data.root_ang_vel_b,
            self.reset_terminated,
            self._robot.data.root_pos_w,
            self._robot.data.root_quat_w,
            self._goal,
            offsets_from_origin,
            self._completed_envs,
            self._actions
        )

        reward_profile = getattr(self.cfg, "reward_profile", LEGACY_REWARD_PROFILE)
        if reward_profile == LEGACY_REWARD_PROFILE:
            total_reward = legacy_reward
            self._last_phase5_2_reward_components = {}
        elif reward_profile == PHASE5_2_REWARD_PROFILE:
            fallback_used, latency_ms = self._phase5_2_solver_health_tensors()
            components = compute_phase52_reward_components(
                legacy_reward=legacy_reward,
                actions=self._actions,
                action_delta=self._last_action_delta_4d,
                pwm=self._last_pwm_8d,
                fallback_used=fallback_used,
                latency_ms=latency_ms,
                config=Phase52RewardConfig.from_env_cfg(self.cfg),
            )
            self._record_phase5_2_reward_components(components)
            total_reward = components["total_reward"]
        else:
            raise ValueError(f"Unknown reward_profile: {reward_profile}")

        ang_mse = math_utils.quat_error_magnitude(self._goal[:,:], self._robot.data.root_quat_w[:,:])
        self.log_MSE += torch.pow(ang_mse,2)

        return total_reward

    def _get_dones(self) -> tuple[torch.Tensor, torch.Tensor]:
        if self.cfg.cap_episode_length:
            time_out = self.episode_length_buf >= self.max_episode_length - 1
        else:
            time_out = torch.zeros(self.num_envs)

        self._step_count = self._step_count + 1

        if self.cfg.episode_length_before_reset:
            if self._step_count == self.cfg.episode_length_before_reset:
                time_out = torch.ones(self.num_envs)

        if self.cfg.use_boundaries:
            out_of_bounds = (
                (torch.abs(self._robot.data.root_pos_w[:, 0] - self.scene.env_origins[:, 0]) > self.cfg.max_auv_x) | 
                (torch.abs(self._robot.data.root_pos_w[:, 1] - self.scene.env_origins[:, 1]) > self.cfg.max_auv_y) | 
                (torch.abs(self._robot.data.root_pos_w[:, 2] - self.cfg.starting_depth) > self.cfg.max_auv_z)
            )
        else:
            out_of_bounds = torch.zeros(self.num_envs)

        return out_of_bounds, time_out

    def _reset_idx(self, env_ids: Sequence[int] | None):
        if env_ids is None:
            env_ids = self._robot._ALL_INDICES
        super()._reset_idx(env_ids)

        self._default_root_state[env_ids, :] = self._robot.data.default_root_state[env_ids]
        self._default_root_state[env_ids, :3] += self.scene.env_origins[env_ids]

        self._default_env_origins[env_ids, :] = self._default_root_state[env_ids, :3]

        if not self.cfg.eval_mode:
            # Randomize initial position relative to the origin
            self._default_root_state[env_ids, :3] += self._sample_from_sphere(len(env_ids), self.cfg.goal_spawn_radius)


        self._step_count = 0
        self._last_action_delta_4d[env_ids] = 0.0
        
        # Apply domain randomization
        self._reset_domain(env_ids)

        # Reset goals
        self._reset_goal(env_ids)

        if not self.cfg.eval_mode:
            # Apply guidance (set to goal position and orientation)
            envs_to_guide = math_utils.sample_uniform(0, 1, len(env_ids), self.device) < self.cfg.init_guidance_rate
            env_ids_to_guide = env_ids[envs_to_guide]
            self._default_root_state[env_ids_to_guide, :3] = self._default_env_origins[env_ids_to_guide, :3]
            self._default_root_state[env_ids_to_guide, 3:7] = self._goal[env_ids_to_guide, 0:4]

        self._robot.write_root_pose_to_sim(self._default_root_state[env_ids, :7], env_ids)
        self._robot.write_root_velocity_to_sim(self._default_root_state[env_ids, 7:], env_ids)

        # logging

        extras = dict()
        extras['Episode Reward / log MSE'] = torch.mean(self.log_MSE[env_ids]) / self.max_episode_length_s
        self.log_MSE[env_ids] = 0.0
        self.extras["log"] = dict()
        self.extras["log"].update(extras)


    # OVERRIDE THIS FUNC TO CHANGE GOAL
    def _reset_goal(self, env_ids: Sequence[int]):
        self._goal[env_ids, 0:4] = math_utils.random_orientation(len(env_ids), device=self.device)


    def _reset_domain(self, env_ids: Sequence[int]):
        self.masses[env_ids] = self.masses[env_ids]

        # Randomize COM to COB offset
        if self.cfg.domain_randomization.use_custom_randomization:
            self.com_to_cob_offsets[env_ids] = self.cfg.com_to_cob_offset[env_ids] + self._sample_from_sphere(len(env_ids), self.cfg.domain_randomization.com_to_cob_offset_radius)

        # Randomize volume
        if self.cfg.domain_randomization.use_custom_randomization:
            vol_lower, vol_upper = self.cfg.domain_randomization.volume_range
            self.volumes[env_ids] = math_utils.sample_uniform(vol_lower, vol_upper, self.volumes[env_ids].shape, self.device)
        

    def _sample_from_circle(self, num_env_ids, r):
        sampled_radius = r * torch.sqrt(torch.rand((num_env_ids), device=self.device))
        sampled_theta = torch.rand((num_env_ids), device=self.device) * 2 * 3.14159
        sampled_x = sampled_radius * torch.cos(sampled_theta)
        sampled_y = sampled_radius * torch.sin(sampled_theta)
        return (sampled_x, sampled_y)

    def _sample_from_sphere(self, num_env_ids, r):
        coords = torch.randn((num_env_ids, 3), device=self.device)
        norms = torch.norm(coords, dim=1).unsqueeze(1)
        coords /= norms

        radii = r * torch.pow(torch.rand((num_env_ids, 1), device=self.device), 1/3)

        return radii * coords

    def _pid_control(self, actions, actions_d, actions_i) -> torch.Tensor:
        motorValue = torch.zeros(self.num_envs, 8, device=self.device)
        actions = actions * self.action_lim; actions_d = actions_d * self.action_lim; actions_i = actions_i * self.action_lim
        if self.cfg.control_method == 'Ssurface':
            coeff_ratio = self.cfg.s_ratio
            PID_value = 2 / (1 + torch.exp(-self.cfg.s_ratio *  self.PID_args[:,:,0] * actions - self.cfg.s_ratio * self.PID_args[:,:,1] * actions_d)) - 1
            if self.cfg.self_adapt:
                PID_value_add = 30 * (1 / 60) * (actions + 1.00 * actions_d)
                PID_value_add = torch.clamp(PID_value_add, -0.35, 0.35)
                PID_value += PID_value_add
        elif self.cfg.control_method == 'PID':
            PID_value = actions * self.PID_args[:,:,0] + actions_d * self.PID_args[:,:,1] + actions_i * self.PID_args[:,:,2]
        motorValue[:,0] = -PID_value[:,0] - PID_value[:,1] + PID_value[:,3] # roll, pitch, depth
        motorValue[:,1] = PID_value[:,0] - PID_value[:,1] + PID_value[:,3]
        motorValue[:,2] = -PID_value[:,0] + PID_value[:,1] + PID_value[:,3]
        motorValue[:,3] = PID_value[:,0] + PID_value[:,1] + PID_value[:,3]
        motorValue[:,4] = PID_value[:,2];
        motorValue[:,5] = -PID_value[:,2]
        motorValue[:,6] = -PID_value[:,2]
        motorValue[:,7] = PID_value[:,2]
        motorValue = torch.clip(motorValue, -1, 1).to(self.device) # clip to PWM values
        return motorValue

    def _compute_dynamics(self, actions) -> Tuple[torch.Tensor, torch.Tensor]:
        """ Compute dynamics from actions.
        actions are -1 for full reverse thrust, 1 for full forward thrust - THESE REPRESENT PWM VALUES
        BASED ON LINE 91 of https://gitlab.com/warplab/ros/warpauv/warpauv_simulation/-/blob/master/src/robot_sim_interface.py
        Args:
            actions (torch.Tensor): Actions shape (num_envs, num_actions)

        Returns:
            [torch.Tensor]: Forces sent to the simulation
            [torch.Tensor]: Torques sent to the simulation
        """

        if self._debug: print("actions: ", actions)

        thruster_forces = torch.zeros((self.num_envs, 8, 3), device=self.device, dtype=torch.float)
        thruster_torques = torch.zeros((self.num_envs, 8, 3), device=self.device, dtype=torch.float)

        action_delta = actions - self.old_actions
        legacy_pwm = self._pid_control(actions, action_delta, self.actions_i) # motorValues (num_envs, 8)
        if self.cfg.controller_mode == 'legacy':
            motorValues = legacy_pwm
            self._last_koopman_mpc_diagnostics = [{} for _ in range(self.num_envs)]
        elif self.cfg.controller_mode == 'koopman_mpc':
            if self._koopman_mpc_controller is None:
                raise RuntimeError("koopman_mpc controller was not initialized")
            state, reference = self._koopman_state_reference()
            motorValues = torch.zeros_like(legacy_pwm)
            diagnostics = []
            for env_index in range(self.num_envs):
                output = self._koopman_mpc_controller.command(
                    state[env_index].detach().cpu().numpy(),
                    reference[env_index].detach().cpu().numpy(),
                    previous_pwm=self._last_pwm_8d[env_index].detach().cpu().numpy(),
                    legacy_pwm=legacy_pwm[env_index].detach().cpu().numpy(),
                )
                motorValues[env_index] = torch.tensor(output.pwm, dtype=torch.float32, device=self.device)
                diagnostics.append(output.diagnostics)
            self._last_koopman_mpc_diagnostics = diagnostics
        else:
            raise ValueError(f"Unknown controller_mode: {self.cfg.controller_mode}")
        self._last_action_delta_4d = action_delta.clone()
        self.old_actions = actions.clone()
        self._last_pwm_8d = motorValues.clone()
        # motorValues = torch.clone(actions) # at this point these are PWM commands between -1 and 1

        if self._debug: print("motorValues: ", motorValues)

        # lower the PWM threshold
        threshold = 0.08

        # thruster dynamics

        motorValues[torch.abs(motorValues) < threshold] = 0 

        motorValues[motorValues >= threshold] = 29.54 * (torch.pow(motorValues[motorValues >= threshold], 2.0)) + 26.1 * motorValues[motorValues >= threshold] - 2.44
        motorValues[motorValues <= -threshold] = -21.75 * (torch.pow(motorValues[motorValues <= -threshold], 2.0)) + 21.75 * motorValues[motorValues <= -threshold] + 2.07

        # TODO: this could be taken out of the physics step
        thruster_forces[..., 0] = 1.0 # start with forces in the x direction
        thruster_forces = quat_apply(self.thruster_quats, thruster_forces) # rotate the forces into the thruster's frame

        # apply the force magnitudes to the thruster forces
        thruster_forces = thruster_forces * motorValues.unsqueeze(-1) # make motorValues shape (num_envs, 6, 1))

        # calculate the thruster torques 
        # T = r x F
        # T (num_envs, num_thrusters_per_env, 3)
        # r (num_thrusters_per_env, 3)
        # F (num_envs, num_thrusters_per_env, 3)
        # it should broadcast r to be (num_envs, num_thrusters_per_env, 3)
        thruster_torques = torch.cross(self.thruster_com_offsets, thruster_forces, dim=-1)

        # now sum together all the forces/torques on each robot
        thruster_forces = torch.sum(thruster_forces, dim=-2) # sum over the thruster indices
        thruster_torques = torch.sum(thruster_torques, dim=-2) # sum over the thruster indices

        ## Calculate hydrodynamics
        if self._debug: print("gravity magnitude: ", self._gravity_magnitude) 
        buoyancy_forces, buoyancy_torques = self.force_calculation_functions.calculate_buoyancy_forces(self._robot.data.root_quat_w, self.cfg.water_rho, self.volumes, abs(self._gravity_magnitude), self.com_to_cob_offsets)

        density_forces, density_torques, viscosity_forces, viscosity_torques = self.force_calculation_functions.calculate_density_and_viscosity_forces(
          self._robot.data.root_quat_w, self._robot.data.root_lin_vel_w, self._robot.data.root_ang_vel_w, self.inertia_tensors, self.inertia_tensors_mean, self.cfg.water_beta, self.cfg.water_rho, self.masses
        )

        if self._debug: print("density forces: ", density_forces)
        if self._debug: print("density torques: ", density_torques)

        if self._debug: print("viscosity forces: ", viscosity_forces)
        if self._debug: print("viscosity torques: ", viscosity_torques)

        if self._debug: print("buoyancy forces: ", buoyancy_forces)
        if self._debug: print("buoyancy torques: ", buoyancy_torques)

        if self._debug: print("thruster forces: ", thruster_forces)
        if self._debug: print("thruster torques: ", thruster_torques)

        forces = density_forces + buoyancy_forces + viscosity_forces + thruster_forces
        torques = density_torques + buoyancy_torques + viscosity_torques + thruster_torques

        if self._debug: print("final forces", forces)
        if self._debug: print("final torques", torques)

        return forces, torques

    def _set_debug_vis_impl(self, debug_vis: bool):
        # create markers if necessary for the first tome
        if debug_vis:
            if not hasattr(self, "goal_pos_visualizer"):
                marker_cfg = CUBOID_MARKER_CFG.copy()
                marker_cfg.markers["cuboid"].size = (0.05, 0.05, 0.05)
                # -- goal pose
                marker_cfg.prim_path = "/Visuals/Command/goal_position"
                self.goal_pos_visualizer = VisualizationMarkers(marker_cfg)

            if not hasattr(self, "goal_ang_visualizer"):
                marker_cfg = RED_ARROW_X_MARKER_CFG.copy()
                marker_cfg.prim_path = "/Visuals/Command/goal_ang"
                marker_cfg.markers["arrow"].scale = (0.125, 0.125, 1)
                self.goal_ang_visualizer = VisualizationMarkers(marker_cfg)

            if not hasattr(self, "goal_z_ang_visualizer"):
                marker_cfg = BLUE_ARROW_X_MARKER_CFG.copy()
                marker_cfg.prim_path = "/Visuals/Command/goal_z_ang"
                marker_cfg.markers["arrow"].scale = (0.125, 0.125, 1)
                self.goal_z_ang_visualizer = VisualizationMarkers(marker_cfg)

            if not hasattr(self, "x_b_visualizer"):
                marker_cfg = GREEN_ARROW_X_MARKER_CFG.copy()
                marker_cfg.markers["arrow"].scale = (0.125, 0.125, 1)
                marker_cfg.prim_path = "/Visuals/Command/x_b"
                self.x_b_visualizer = VisualizationMarkers(marker_cfg)

            if not hasattr(self, "z_b_visualizer"):
                marker_cfg = GREEN_ARROW_X_MARKER_CFG.copy()
                marker_cfg.markers["arrow"].scale = (0.125, 0.125, 1)
                marker_cfg.prim_path = "/Visuals/Command/z_b"
                self.z_b_visualizer = VisualizationMarkers(marker_cfg)
            
            # set their visibility to true
            self.goal_pos_visualizer.set_visibility(True)
            self.goal_ang_visualizer.set_visibility(True)
            self.goal_z_ang_visualizer.set_visibility(True)
            self.x_b_visualizer.set_visibility(True)
            self.z_b_visualizer.set_visibility(True)

        else:
            if hasattr(self, "goal_pos_visualizer"):
                self.goal_pos_visualizer.set_visibility(False)

            if hasattr(self, "goal_ang_visualizer"):
                self.goal_ang_visualizer.set_visibility(False)

            if hasattr(self, "goal_z_ang_visualizer"):
                self.goal_z_ang_visualizer.set_visibility(False)

            if hasattr(self, "x_b_visualizer"):
                self.x_b_visualizer.set_visibility(False)
            
            if hasattr(self, "z_b_visualizer"):
                self.z_b_visualizer.set_visibility(False)

    def _rotate_quat_by_euler_xyz(self, q: torch.tensor, x: float|torch.tensor, y: float|torch.tensor, z: float|torch.tensor, device=None):
        # Assumes q has shape [num_envs, 4]
        num_envs = q.shape[0]
        if device == None:
            device = self.device

        if type(x) == float:
            x = torch.zeros(num_envs, device=device) + x

        if type(y) == float:
            y = torch.zeros(num_envs, device=device) + y
        
        if type(z) == float:
            z = torch.zeros(num_envs, device=device) + z

        iq = math_utils.quat_from_euler_xyz(x, y, z)
        return math_utils.quat_mul(q, iq)


    def _debug_vis_callback(self, event):
        # Visualize the goal positions
        # self.goal_pos_visualizer.visualize(translations = self._default_env_origins)
        self.goal_pos_visualizer.visualize(translations = self._goal_pos_w)

        # Visualize goal orientations
        goal_quats_w = self._goal
        ang_marker_scales = torch.tensor([1, 1, 1]).repeat(self.num_envs, 1)
        ang_marker_scales[:, 0] = 1
        self.goal_ang_visualizer.visualize(translations=self._robot.data.root_pos_w, orientations=goal_quats_w, scales=ang_marker_scales)

        # Visualize goal orientations via another axis
        goal_z_quat = self._rotate_quat_by_euler_xyz(goal_quats_w, 0.0, -torch.pi/2, 0.0)
        ang_marker_scales = torch.tensor([1, 1, 1]).repeat(self.num_envs, 1)
        ang_marker_scales[:, 0] = 1
        self.goal_z_ang_visualizer.visualize(translations=self._robot.data.root_pos_w, orientations=goal_z_quat, scales=ang_marker_scales)

        # Visualize current X-direction
        x_w = self._robot.data.root_quat_w
        x_w_marker_scales = torch.tensor([1, 1, 1]).repeat(self.num_envs, 1)
        x_w_marker_scales[:, 0] = 1
        self.x_b_visualizer.visualize(translations=self._robot.data.root_pos_w, orientations=x_w, scales=x_w_marker_scales)

        # Visualize current Z-direction
        z_w_quat = self._rotate_quat_by_euler_xyz(self._robot.data.root_quat_w, 0.0, -torch.pi/2, 0.0)
        z_w_marker_scales = torch.tensor([1, 1, 1]).repeat(self.num_envs, 1)
        z_w_marker_scales[:, 0] = 1
        self.z_b_visualizer.visualize(translations=self._robot.data.root_pos_w, orientations=z_w_quat, scales=z_w_marker_scales)


@torch.jit.script
def quat_dist(q1, q2):
    return 1 - torch.sum(q1*q2, dim=-1)**2

@torch.jit.script
def _compute_rewards(
    rew_scale_pos: float,
    rew_scale_ang: float,
    rew_scale_lin_vel: float,
    rew_scale_ang_vel: float,
    rew_scale_actions: float,
    lin_vel: torch.Tensor,
    ang_vel: torch.Tensor,
    reset_terminated: torch.Tensor,
    root_pos: torch.Tensor,
    root_quat: torch.Tensor,
    goal: torch.Tensor,
    offsets_from_origin: torch.Tensor,
    completed_envs: torch.Tensor,
    actions: torch.Tensor,
):

    # Reward depth accuracy
    rew_pos = rew_scale_pos * torch.exp(-1 * (torch.abs(offsets_from_origin[:,2]) ** 2))

    # Reward angular accuracy, todo: scale the gaussian std appropriately
    # Uniquefy and normalize all quaternions
    rew_ang = rew_scale_ang * torch.exp(-1 * math_utils.quat_error_magnitude(goal[:,:], root_quat[:,:]))

    # Penalize angular velocity
    rew_ang_vel = rew_scale_ang_vel * torch.exp(-1 * torch.norm(ang_vel, dim=1)**2)

    # # Penalize energy consumption
    rew_action = rew_scale_actions * torch.exp(-1 * torch.norm(actions, dim=1) ** 0.5)

    total_rew = rew_ang + rew_action + rew_pos + rew_ang_vel

    return total_rew
